﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1._11._2021_DB_
{
    public partial class Zadacha2v1 : Form
    {
        public Zadacha2v1()
        {
            InitializeComponent();
        }

        private void fillData()
        {
            try
            {
                decimal Volume = decimal.Parse(txtVolume.Text);
                string FromDate = dtpFrom.Text;
                zadacha2TableAdapter.Fill(myDataSet.Zadacha2, FromDate, Volume);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnFillz2v1_Click(object sender, EventArgs e)
        {
            fillData();
        }

        private void Zadacha2v1_Load(object sender, EventArgs e)
        {
            fillData();
        }
    }
}
