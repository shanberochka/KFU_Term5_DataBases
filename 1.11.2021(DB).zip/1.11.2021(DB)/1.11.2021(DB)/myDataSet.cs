﻿namespace _1._11._2021_DB_
{


    partial class myDataSet
    {
        partial class DetailsDataTable
        {
        }

        partial class Zadacha1DataTable
        {
        }

        partial class AlterTableDataTable
        {
        }
    }
}
