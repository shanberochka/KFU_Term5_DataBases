﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1._11._2021_DB_
{
    public partial class Zadacha3v2 : Form
    {
        public Zadacha3v2()
        {
            InitializeComponent();
        }

        private void Zadacha3v2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.Details". При необходимости она может быть перемещена или удалена.
            this.detailsTableAdapter.Fill(this.myDataSet.Details);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.Customers". При необходимости она может быть перемещена или удалена.
            this.customersTableAdapter.Fill(this.myDataSet.Customers);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.Acc_Shipment". При необходимости она может быть перемещена или удалена.
            this.acc_ShipmentTableAdapter.Fill(this.myDataSet.Acc_Shipment);
            FillDataGridView();
        }

        private void FillDataGridView()
        {
            myDataSet.Zadacha3.Clear();
            var storage = int.Parse(txtStorage.Text);
            var price = decimal.Parse(txtPrice.Text);
            foreach(myDataSet.CustomersRow cRow in myDataSet.Customers.Rows)
            {
                bool eDetail = false;
                foreach(myDataSet.DetailsRow dRow in myDataSet.Details.Rows)
                {
                    if (dRow.price_DET < price || dRow.type_DET == "покупная")
                    {
                        continue;
                    }
                    bool aOrder = true;
                    bool eOrder = false;
                    foreach(myDataSet.Acc_ShipmentRow oRow in myDataSet.Acc_Shipment.Rows)
                    {
                        if (oRow.code_RPROD==dRow.code_DET && oRow.code_CUS==cRow.code_CUS)
                        {
                            if (oRow.code_STRG == storage)
                            {
                                eOrder = true;
                                continue;
                            }
                            else
                            {
                                aOrder = false;
                                break;
                            }
                        }
                    }
                    if (aOrder && eOrder)
                    {
                        eDetail = true; 
                        break;
                    }
                }
                if (eDetail)
                    {
                        myDataSet.Zadacha3Row zRow = myDataSet.Zadacha3.NewZadacha3Row();
                        zRow.name_CUS = cRow.name_CUS;
                        myDataSet.Zadacha3.Rows.Add(zRow);
                    }
            }
        }
      

        private void btnFill_Click(object sender, EventArgs e)
        {
            FillDataGridView();
        }

        private void txtPrice_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                FillDataGridView();
            }
        }

        private void txtStorage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                FillDataGridView();
            }
        }
    }
}