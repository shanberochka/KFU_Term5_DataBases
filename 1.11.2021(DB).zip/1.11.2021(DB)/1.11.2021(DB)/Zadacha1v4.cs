﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1._11._2021_DB_
{
    public partial class Zadacha1v4 : Form
    {
        public Zadacha1v4()
        {
            InitializeComponent();
        }

        private void Zadacha1v4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.Details". При необходимости она может быть перемещена или удалена.
            this.detailsTableAdapter.Fill(this.myDataSet.Details);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.Acc_Shipment". При необходимости она может быть перемещена или удалена.
            this.acc_ShipmentTableAdapter.Fill(this.myDataSet.Acc_Shipment);
            QueryZapr3();
        }
        private void QueryZapr3()
        {
            int count = int.Parse(txtCount.Text);
            myDataSet.Zadacha1.Clear();
            foreach (myDataSet.Acc_ShipmentRow oRow in myDataSet.Acc_Shipment.Rows)
            {
                if (oRow.count_PROD < count)
                {
                    continue;
                }
                myDataSet.DetailsRow dRow = oRow.GetParentRow("FK_Det_Shipment") as myDataSet.DetailsRow;

                myDataSet.Zadacha1Row zRow = myDataSet.Zadacha1.NewZadacha1Row();
                zRow.name_DET = dRow.name_DET;
                zRow.date_SHIPMENT = oRow.date_SHIPMENT;
                zRow.price_DET = dRow.price_DET;
                zRow.count_PROD = oRow.count_PROD;
                myDataSet.Zadacha1.Rows.Add(zRow);
            }
        }
        private void btnFill_Click(object sender, EventArgs e)
        {
            QueryZapr3();
        }

        private void txtCount_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                QueryZapr3();
            }
        }
    }
}
