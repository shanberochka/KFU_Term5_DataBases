﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1._11._2021_DB_
{
    public partial class Zadacha1v1 : Form
    {
        public Zadacha1v1()
        {
            InitializeComponent();
        }

        private void fillData()
        {
            try
            {
                int count = int.Parse(txtCount.Text);
                zadacha1TableAdapter.Fill(myDataSet.Zadacha1, count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        private void btnFill_Click(object sender, EventArgs e)
        {
            fillData();
        }

        private void Zadacha1v1_Load(object sender, EventArgs e)
        {
            fillData();
        }

        private void txtCount_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                fillData();
            }
        }
    }
}
