﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1._11._2021_DB_
{
    public partial class AlterForm : Form
    {
        public AlterForm()
        {
            InitializeComponent();
        }

        private void AlterForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet1.Details". При необходимости она может быть перемещена или удалена.
            this.detailsTableAdapter.Fill(this.myDataSet1.Details);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet1.Customers". При необходимости она может быть перемещена или удалена.
            this.customersTableAdapter.Fill(this.myDataSet1.Customers);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet1.Acc_Shipment". При необходимости она может быть перемещена или удалена.
            this.acc_ShipmentTableAdapter.Fill(this.myDataSet1.Acc_Shipment);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.AlterTable". При необходимости она может быть перемещена или удалена.
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dgvAlterTable.DataSource = accShipmentBindingSource;
            bnAlter.BindingSource = accShipmentBindingSource;
        }

        private void btnCustAlter_Click(object sender, EventArgs e)
        {
            dgvAlterTable.DataSource = customersBindingSource;
            bnAlter.BindingSource = customersBindingSource;
        }

        private void btnDetailsAlter_Click(object sender, EventArgs e)
        {
            dgvAlterTable.DataSource = detailsBindingSource;
            bnAlter.BindingSource = detailsBindingSource;
        }
    }
}
