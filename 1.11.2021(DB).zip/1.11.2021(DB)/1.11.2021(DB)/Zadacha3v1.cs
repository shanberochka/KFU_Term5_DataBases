﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1._11._2021_DB_
{
    public partial class Zadacha3v1 : Form
    {
        public Zadacha3v1()
        {
            InitializeComponent();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            FillDataGridView();
        }

       
        private void FillDataGridView()
        {
            var storage = int.Parse(txtStorage.Text);
            var price = decimal.Parse(txtPrice.Text);

            zadacha3TableAdapter.Fill(myDataSet.Zadacha3, price, storage);//, price, date1//date1.ToShortDateString()
        }

        private void txtStorage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                FillDataGridView();
            }
        }

        private void txtPrice_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                FillDataGridView();
            }
        }

        private void Zadacha3v1_Load(object sender, EventArgs e)
        {
            FillDataGridView();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FillDataGridView();
        }
    }
}
