﻿
namespace _1._11._2021_DB_
{
    partial class AlterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AlterForm));
            this.dgvAlterTable = new System.Windows.Forms.DataGridView();
            this.myDataSet = new _1._11._2021_DB_.myDataSet();
            this.bnAlter = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.myDataSet1 = new _1._11._2021_DB_.myDataSet();
            this.accShipmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.acc_ShipmentTableAdapter = new _1._11._2021_DB_.myDataSetTableAdapters.Acc_ShipmentTableAdapter();
            this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customersTableAdapter = new _1._11._2021_DB_.myDataSetTableAdapters.CustomersTableAdapter();
            this.detailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.detailsTableAdapter = new _1._11._2021_DB_.myDataSetTableAdapters.DetailsTableAdapter();
            this.btnOrdersAlter = new System.Windows.Forms.Button();
            this.btnDetailsAlter = new System.Windows.Forms.Button();
            this.btnCustAlter = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlterTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bnAlter)).BeginInit();
            this.bnAlter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.myDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accShipmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.detailsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvAlterTable
            // 
            this.dgvAlterTable.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAlterTable.BackgroundColor = System.Drawing.Color.LemonChiffon;
            this.dgvAlterTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAlterTable.Location = new System.Drawing.Point(0, 40);
            this.dgvAlterTable.Name = "dgvAlterTable";
            this.dgvAlterTable.Size = new System.Drawing.Size(735, 124);
            this.dgvAlterTable.TabIndex = 0;
            // 
            // myDataSet
            // 
            this.myDataSet.DataSetName = "myDataSet";
            this.myDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bnAlter
            // 
            this.bnAlter.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bnAlter.CountItem = this.bindingNavigatorCountItem;
            this.bnAlter.DeleteItem = this.bindingNavigatorDeleteItem;
            this.bnAlter.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem});
            this.bnAlter.Location = new System.Drawing.Point(0, 0);
            this.bnAlter.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bnAlter.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bnAlter.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bnAlter.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bnAlter.Name = "bnAlter";
            this.bnAlter.PositionItem = this.bindingNavigatorPositionItem;
            this.bnAlter.Size = new System.Drawing.Size(800, 25);
            this.bnAlter.TabIndex = 1;
            this.bnAlter.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // myDataSet1
            // 
            this.myDataSet1.DataSetName = "myDataSet";
            this.myDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // accShipmentBindingSource
            // 
            this.accShipmentBindingSource.DataMember = "Acc_Shipment";
            this.accShipmentBindingSource.DataSource = this.myDataSet1;
            // 
            // acc_ShipmentTableAdapter
            // 
            this.acc_ShipmentTableAdapter.ClearBeforeFill = true;
            // 
            // customersBindingSource
            // 
            this.customersBindingSource.DataMember = "Customers";
            this.customersBindingSource.DataSource = this.myDataSet1;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // detailsBindingSource
            // 
            this.detailsBindingSource.DataMember = "Details";
            this.detailsBindingSource.DataSource = this.myDataSet1;
            // 
            // detailsTableAdapter
            // 
            this.detailsTableAdapter.ClearBeforeFill = true;
            // 
            // btnOrdersAlter
            // 
            this.btnOrdersAlter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnOrdersAlter.Location = new System.Drawing.Point(88, 214);
            this.btnOrdersAlter.Name = "btnOrdersAlter";
            this.btnOrdersAlter.Size = new System.Drawing.Size(75, 23);
            this.btnOrdersAlter.TabIndex = 2;
            this.btnOrdersAlter.Text = "Orders";
            this.btnOrdersAlter.UseVisualStyleBackColor = true;
            this.btnOrdersAlter.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDetailsAlter
            // 
            this.btnDetailsAlter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDetailsAlter.Location = new System.Drawing.Point(605, 214);
            this.btnDetailsAlter.Name = "btnDetailsAlter";
            this.btnDetailsAlter.Size = new System.Drawing.Size(75, 23);
            this.btnDetailsAlter.TabIndex = 3;
            this.btnDetailsAlter.Text = "Details";
            this.btnDetailsAlter.UseVisualStyleBackColor = true;
            this.btnDetailsAlter.Click += new System.EventHandler(this.btnDetailsAlter_Click);
            // 
            // btnCustAlter
            // 
            this.btnCustAlter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCustAlter.Location = new System.Drawing.Point(353, 214);
            this.btnCustAlter.Name = "btnCustAlter";
            this.btnCustAlter.Size = new System.Drawing.Size(75, 23);
            this.btnCustAlter.TabIndex = 4;
            this.btnCustAlter.Text = "Customers";
            this.btnCustAlter.UseVisualStyleBackColor = true;
            this.btnCustAlter.Click += new System.EventHandler(this.btnCustAlter_Click);
            // 
            // AlterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LemonChiffon;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCustAlter);
            this.Controls.Add(this.btnDetailsAlter);
            this.Controls.Add(this.btnOrdersAlter);
            this.Controls.Add(this.bnAlter);
            this.Controls.Add(this.dgvAlterTable);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AlterForm";
            this.Text = "AlterForm";
            this.Load += new System.EventHandler(this.AlterForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlterTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bnAlter)).EndInit();
            this.bnAlter.ResumeLayout(false);
            this.bnAlter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.myDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accShipmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.detailsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvAlterTable;
        private myDataSet myDataSet;
        private System.Windows.Forms.BindingNavigator bnAlter;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private myDataSet myDataSet1;
        private System.Windows.Forms.BindingSource accShipmentBindingSource;
        private myDataSetTableAdapters.Acc_ShipmentTableAdapter acc_ShipmentTableAdapter;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private myDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
        private System.Windows.Forms.BindingSource detailsBindingSource;
        private myDataSetTableAdapters.DetailsTableAdapter detailsTableAdapter;
        private System.Windows.Forms.Button btnOrdersAlter;
        private System.Windows.Forms.Button btnDetailsAlter;
        private System.Windows.Forms.Button btnCustAlter;
    }
}