﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1._11._2021_DB_
{
    public partial class Zadacha2v2 : Form
    {
        public Zadacha2v2()
        {
            InitializeComponent();
        }

        private void Zadacha2v2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.Details". При необходимости она может быть перемещена или удалена.
            this.detailsTableAdapter.Fill(this.myDataSet.Details);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.Acc_Shipment". При необходимости она может быть перемещена или удалена.
            this.acc_ShipmentTableAdapter.Fill(this.myDataSet.Acc_Shipment);
            QueryZapr2();
        }
        private void QueryZapr2()
        {
            decimal Volume = decimal.Parse(txtVolume.Text);
            DateTime FromDate = DateTime.Parse(dtpFrom.Text);
            myDataSet.Zadacha2.Clear();
            foreach(myDataSet.DetailsRow dRow in myDataSet.Details.Rows)
            {
                decimal SumAll = 0;
                myDataSet.Acc_ShipmentRow[] oRows = dRow.GetChildRows("FK_Det_Shipment") as myDataSet.Acc_ShipmentRow[];
                foreach (myDataSet.Acc_ShipmentRow oRow in oRows)
                {
                    if (oRow.date_SHIPMENT < FromDate)
                    {
                        continue;
                    }
                    SumAll += oRow.count_PROD * dRow.price_DET;

                }
                if (SumAll <= Volume)
                {
                    continue;
                }
                else
                {
                    myDataSet.Zadacha2Row zRow = myDataSet.Zadacha2.NewZadacha2Row();
                    zRow.name = dRow.name_DET;
                    zRow.volume_of_sales = SumAll;
                    myDataSet.Zadacha2.Rows.Add(zRow); 
                }
                          
            }
        }

        private void btnFillz2v1_Click(object sender, EventArgs e)
        {
            QueryZapr2();
        }
    }
}
