﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1._11._2021_DB_
{
    public partial class View_Form : Form
    {
        public View_Form()
        {
            InitializeComponent();
        }

        private void View_Form_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.view_task". При необходимости она может быть перемещена или удалена.
            this.view_taskTableAdapter.Fill(this.myDataSet.view_task);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.View". При необходимости она может быть перемещена или удалена.
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
