﻿
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace _1._11._2021_DB_
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dgvCustomers = new System.Windows.Forms.DataGridView();
            this.nameCUSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addCUSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myDataSet = new _1._11._2021_DB_.myDataSet();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.dgvDetails = new System.Windows.Forms.DataGridView();
            this.typeDETDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDETDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitDETDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDETDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.detailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dgvAcc_Shipment = new System.Windows.Forms.DataGridView();
            this.codeDOCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.code_STRG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateSHIPMENTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.code_CUS = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.code_RPROD = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.selfDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.unitPRODDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.countPRODDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accShipmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnSave = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrev = new System.Windows.Forms.Button();
            this.lbl = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.lblDate_from = new System.Windows.Forms.Label();
            this.lblDate_to = new System.Windows.Forms.Label();
            this.btnProc = new System.Windows.Forms.Button();
            this.lblProc = new System.Windows.Forms.Label();
            this.lblCustomers = new System.Windows.Forms.Label();
            this.lblDetails = new System.Windows.Forms.Label();
            this.lblAcc_Shipment = new System.Windows.Forms.Label();
            this.dgvUnion = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.формыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.основнаяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.альтернативнаяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.представлениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задача1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вариант1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вариант2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вариант3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вариант4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вариант5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задача2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sQLзапросToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recordподходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задача3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вариант1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.вариант2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fKCustShipmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fKDetShipmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customersTableAdapter = new _1._11._2021_DB_.myDataSetTableAdapters.CustomersTableAdapter();
            this.detailsTableAdapter = new _1._11._2021_DB_.myDataSetTableAdapters.DetailsTableAdapter();
            this.acc_ShipmentTableAdapter = new _1._11._2021_DB_.myDataSetTableAdapters.Acc_ShipmentTableAdapter();
            this.selfDetailsTableAdapter = new _1._11._2021_DB_.myDataSetTableAdapters.SelfDetailsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.detailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAcc_Shipment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.selfDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accShipmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUnion)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fKCustShipmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKDetShipmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvCustomers
            // 
            this.dgvCustomers.AutoGenerateColumns = false;
            this.dgvCustomers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameCUSDataGridViewTextBoxColumn,
            this.addCUSDataGridViewTextBoxColumn});
            this.dgvCustomers.DataSource = this.customersBindingSource;
            this.dgvCustomers.Location = new System.Drawing.Point(257, 44);
            this.dgvCustomers.Name = "dgvCustomers";
            this.dgvCustomers.Size = new System.Drawing.Size(260, 172);
            this.dgvCustomers.TabIndex = 0;
            this.dgvCustomers.Click += new System.EventHandler(this.dgvCustomers_Click);
            // 
            // nameCUSDataGridViewTextBoxColumn
            // 
            this.nameCUSDataGridViewTextBoxColumn.DataPropertyName = "name_CUS";
            this.nameCUSDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameCUSDataGridViewTextBoxColumn.Name = "nameCUSDataGridViewTextBoxColumn";
            // 
            // addCUSDataGridViewTextBoxColumn
            // 
            this.addCUSDataGridViewTextBoxColumn.DataPropertyName = "add_CUS";
            this.addCUSDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addCUSDataGridViewTextBoxColumn.Name = "addCUSDataGridViewTextBoxColumn";
            // 
            // customersBindingSource
            // 
            this.customersBindingSource.DataMember = "Customers";
            this.customersBindingSource.DataSource = this.myDataSet;
            // 
            // myDataSet
            // 
            this.myDataSet.DataSetName = "myDataSet";
            this.myDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bindingNavigator1.BindingSource = this.customersBindingSource;
            this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator1.DeleteItem = this.bindingNavigatorDeleteItem;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem});
            this.bindingNavigator1.Location = new System.Drawing.Point(0, 24);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator1.Size = new System.Drawing.Size(999, 25);
            this.bindingNavigator1.TabIndex = 1;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // dgvDetails
            // 
            this.dgvDetails.AutoGenerateColumns = false;
            this.dgvDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.typeDETDataGridViewTextBoxColumn,
            this.nameDETDataGridViewTextBoxColumn,
            this.unitDETDataGridViewTextBoxColumn,
            this.priceDETDataGridViewTextBoxColumn});
            this.dgvDetails.DataSource = this.detailsBindingSource;
            this.dgvDetails.Location = new System.Drawing.Point(534, 44);
            this.dgvDetails.Name = "dgvDetails";
            this.dgvDetails.Size = new System.Drawing.Size(465, 172);
            this.dgvDetails.TabIndex = 2;
            this.dgvDetails.Click += new System.EventHandler(this.dgvDetails_Click);
            // 
            // typeDETDataGridViewTextBoxColumn
            // 
            this.typeDETDataGridViewTextBoxColumn.DataPropertyName = "type_DET";
            this.typeDETDataGridViewTextBoxColumn.HeaderText = "Type";
            this.typeDETDataGridViewTextBoxColumn.Name = "typeDETDataGridViewTextBoxColumn";
            // 
            // nameDETDataGridViewTextBoxColumn
            // 
            this.nameDETDataGridViewTextBoxColumn.DataPropertyName = "name_DET";
            this.nameDETDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDETDataGridViewTextBoxColumn.Name = "nameDETDataGridViewTextBoxColumn";
            // 
            // unitDETDataGridViewTextBoxColumn
            // 
            this.unitDETDataGridViewTextBoxColumn.DataPropertyName = "unit_DET";
            this.unitDETDataGridViewTextBoxColumn.HeaderText = "Unit";
            this.unitDETDataGridViewTextBoxColumn.Name = "unitDETDataGridViewTextBoxColumn";
            // 
            // priceDETDataGridViewTextBoxColumn
            // 
            this.priceDETDataGridViewTextBoxColumn.DataPropertyName = "price_DET";
            this.priceDETDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDETDataGridViewTextBoxColumn.Name = "priceDETDataGridViewTextBoxColumn";
            // 
            // detailsBindingSource
            // 
            this.detailsBindingSource.DataMember = "Details";
            this.detailsBindingSource.DataSource = this.myDataSet;
            // 
            // dgvAcc_Shipment
            // 
            this.dgvAcc_Shipment.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvAcc_Shipment.AutoGenerateColumns = false;
            this.dgvAcc_Shipment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAcc_Shipment.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.codeDOCDataGridViewTextBoxColumn,
            this.code_STRG,
            this.dateSHIPMENTDataGridViewTextBoxColumn,
            this.code_CUS,
            this.code_RPROD,
            this.unitPRODDataGridViewTextBoxColumn,
            this.countPRODDataGridViewTextBoxColumn});
            this.dgvAcc_Shipment.DataSource = this.accShipmentBindingSource;
            this.dgvAcc_Shipment.Location = new System.Drawing.Point(0, 243);
            this.dgvAcc_Shipment.Name = "dgvAcc_Shipment";
            this.dgvAcc_Shipment.Size = new System.Drawing.Size(752, 286);
            this.dgvAcc_Shipment.TabIndex = 3;
            this.dgvAcc_Shipment.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvAcc_Shipment_DataError);
            this.dgvAcc_Shipment.Click += new System.EventHandler(this.dgvAcc_Shipment_Click);
            // 
            // codeDOCDataGridViewTextBoxColumn
            // 
            this.codeDOCDataGridViewTextBoxColumn.DataPropertyName = "code_DOC";
            this.codeDOCDataGridViewTextBoxColumn.HeaderText = "ID Doc";
            this.codeDOCDataGridViewTextBoxColumn.Name = "codeDOCDataGridViewTextBoxColumn";
            // 
            // code_STRG
            // 
            this.code_STRG.DataPropertyName = "code_STRG";
            this.code_STRG.HeaderText = "ID Storage";
            this.code_STRG.Name = "code_STRG";
            this.code_STRG.ReadOnly = true;
            // 
            // dateSHIPMENTDataGridViewTextBoxColumn
            // 
            this.dateSHIPMENTDataGridViewTextBoxColumn.DataPropertyName = "date_SHIPMENT";
            this.dateSHIPMENTDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateSHIPMENTDataGridViewTextBoxColumn.Name = "dateSHIPMENTDataGridViewTextBoxColumn";
            // 
            // code_CUS
            // 
            this.code_CUS.DataPropertyName = "code_CUS";
            this.code_CUS.DataSource = this.customersBindingSource;
            this.code_CUS.DisplayMember = "name_CUS";
            this.code_CUS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.code_CUS.HeaderText = "Customer";
            this.code_CUS.Name = "code_CUS";
            this.code_CUS.ValueMember = "code_CUS";
            // 
            // code_RPROD
            // 
            this.code_RPROD.DataPropertyName = "code_RPROD";
            this.code_RPROD.DataSource = this.selfDetailsBindingSource;
            this.code_RPROD.DisplayMember = "name_DET";
            this.code_RPROD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.code_RPROD.HeaderText = "Detail";
            this.code_RPROD.Name = "code_RPROD";
            this.code_RPROD.ValueMember = "code_DET";
            // 
            // selfDetailsBindingSource
            // 
            this.selfDetailsBindingSource.DataMember = "SelfDetails";
            this.selfDetailsBindingSource.DataSource = this.myDataSet;
            // 
            // unitPRODDataGridViewTextBoxColumn
            // 
            this.unitPRODDataGridViewTextBoxColumn.DataPropertyName = "unit_PROD";
            this.unitPRODDataGridViewTextBoxColumn.HeaderText = "Unit";
            this.unitPRODDataGridViewTextBoxColumn.Name = "unitPRODDataGridViewTextBoxColumn";
            // 
            // countPRODDataGridViewTextBoxColumn
            // 
            this.countPRODDataGridViewTextBoxColumn.DataPropertyName = "count_PROD";
            this.countPRODDataGridViewTextBoxColumn.HeaderText = "Amount";
            this.countPRODDataGridViewTextBoxColumn.Name = "countPRODDataGridViewTextBoxColumn";
            // 
            // accShipmentBindingSource
            // 
            this.accShipmentBindingSource.DataMember = "Acc_Shipment";
            this.accShipmentBindingSource.DataSource = this.myDataSet;
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSave.Location = new System.Drawing.Point(811, 254);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = " Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnNext.Location = new System.Drawing.Point(811, 284);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 5;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrev
            // 
            this.btnPrev.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPrev.Location = new System.Drawing.Point(811, 314);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(75, 23);
            this.btnPrev.TabIndex = 6;
            this.btnPrev.Text = "Previous";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbl.Location = new System.Drawing.Point(309, 9);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(62, 15);
            this.lbl.TabIndex = 8;
            this.lbl.Text = "Customers";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(51, 71);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 9;
            this.dateTimePicker1.Value = new System.DateTime(2021, 1, 1, 0, 0, 0, 0);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(51, 108);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 10;
            this.dateTimePicker2.Value = new System.DateTime(2021, 12, 31, 0, 0, 0, 0);
            // 
            // lblDate_from
            // 
            this.lblDate_from.AutoSize = true;
            this.lblDate_from.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblDate_from.Location = new System.Drawing.Point(12, 71);
            this.lblDate_from.Name = "lblDate_from";
            this.lblDate_from.Size = new System.Drawing.Size(33, 15);
            this.lblDate_from.TabIndex = 11;
            this.lblDate_from.Text = "From";
            // 
            // lblDate_to
            // 
            this.lblDate_to.AutoSize = true;
            this.lblDate_to.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblDate_to.Location = new System.Drawing.Point(12, 108);
            this.lblDate_to.Name = "lblDate_to";
            this.lblDate_to.Size = new System.Drawing.Size(19, 15);
            this.lblDate_to.TabIndex = 12;
            this.lblDate_to.Text = "To";
            // 
            // btnProc
            // 
            this.btnProc.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnProc.Location = new System.Drawing.Point(15, 145);
            this.btnProc.Name = "btnProc";
            this.btnProc.Size = new System.Drawing.Size(75, 23);
            this.btnProc.TabIndex = 13;
            this.btnProc.Text = "Execute";
            this.btnProc.UseVisualStyleBackColor = true;
            this.btnProc.Click += new System.EventHandler(this.btnProc_Click);
            // 
            // lblProc
            // 
            this.lblProc.AutoSize = true;
            this.lblProc.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblProc.Location = new System.Drawing.Point(106, 149);
            this.lblProc.Name = "lblProc";
            this.lblProc.Size = new System.Drawing.Size(39, 15);
            this.lblProc.TabIndex = 14;
            this.lblProc.Text = "Result";
            // 
            // lblCustomers
            // 
            this.lblCustomers.AutoSize = true;
            this.lblCustomers.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCustomers.Location = new System.Drawing.Point(257, 25);
            this.lblCustomers.Name = "lblCustomers";
            this.lblCustomers.Size = new System.Drawing.Size(62, 15);
            this.lblCustomers.TabIndex = 15;
            this.lblCustomers.Text = "Customers";
            // 
            // lblDetails
            // 
            this.lblDetails.AutoSize = true;
            this.lblDetails.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblDetails.Location = new System.Drawing.Point(543, 25);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(43, 15);
            this.lblDetails.TabIndex = 16;
            this.lblDetails.Text = "Details";
            // 
            // lblAcc_Shipment
            // 
            this.lblAcc_Shipment.AutoSize = true;
            this.lblAcc_Shipment.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblAcc_Shipment.Location = new System.Drawing.Point(12, 225);
            this.lblAcc_Shipment.Name = "lblAcc_Shipment";
            this.lblAcc_Shipment.Size = new System.Drawing.Size(118, 15);
            this.lblAcc_Shipment.TabIndex = 17;
            this.lblAcc_Shipment.Text = "Account of Shipment";
            // 
            // dgvUnion
            // 
            this.dgvUnion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUnion.Location = new System.Drawing.Point(257, 66);
            this.dgvUnion.Name = "dgvUnion";
            this.dgvUnion.Size = new System.Drawing.Size(730, 150);
            this.dgvUnion.TabIndex = 19;
            this.dgvUnion.Visible = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.формыToolStripMenuItem,
            this.задача1ToolStripMenuItem,
            this.задача2ToolStripMenuItem,
            this.задача3ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(999, 24);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // формыToolStripMenuItem
            // 
            this.формыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.основнаяToolStripMenuItem,
            this.альтернативнаяToolStripMenuItem,
            this.представлениеToolStripMenuItem});
            this.формыToolStripMenuItem.Name = "формыToolStripMenuItem";
            this.формыToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.формыToolStripMenuItem.Text = "Формы";
            // 
            // основнаяToolStripMenuItem
            // 
            this.основнаяToolStripMenuItem.Name = "основнаяToolStripMenuItem";
            this.основнаяToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.основнаяToolStripMenuItem.Text = "Основная";
            // 
            // альтернативнаяToolStripMenuItem
            // 
            this.альтернативнаяToolStripMenuItem.Name = "альтернативнаяToolStripMenuItem";
            this.альтернативнаяToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.альтернативнаяToolStripMenuItem.Text = "Альтернативная";
            this.альтернативнаяToolStripMenuItem.Click += new System.EventHandler(this.альтернативнаяToolStripMenuItem_Click);
            // 
            // представлениеToolStripMenuItem
            // 
            this.представлениеToolStripMenuItem.Name = "представлениеToolStripMenuItem";
            this.представлениеToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.представлениеToolStripMenuItem.Text = "Представление";
            this.представлениеToolStripMenuItem.Click += new System.EventHandler(this.представлениеToolStripMenuItem_Click);
            // 
            // задача1ToolStripMenuItem
            // 
            this.задача1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вариант1ToolStripMenuItem,
            this.вариант2ToolStripMenuItem,
            this.вариант3ToolStripMenuItem,
            this.вариант4ToolStripMenuItem,
            this.вариант5ToolStripMenuItem});
            this.задача1ToolStripMenuItem.Name = "задача1ToolStripMenuItem";
            this.задача1ToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.задача1ToolStripMenuItem.Text = "Задача 1";
            // 
            // вариант1ToolStripMenuItem
            // 
            this.вариант1ToolStripMenuItem.Name = "вариант1ToolStripMenuItem";
            this.вариант1ToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.вариант1ToolStripMenuItem.Text = "Вариант 1";
            this.вариант1ToolStripMenuItem.Click += new System.EventHandler(this.вариант1ToolStripMenuItem_Click);
            // 
            // вариант2ToolStripMenuItem
            // 
            this.вариант2ToolStripMenuItem.Name = "вариант2ToolStripMenuItem";
            this.вариант2ToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.вариант2ToolStripMenuItem.Text = "Вариант 2";
            this.вариант2ToolStripMenuItem.Click += new System.EventHandler(this.вариант2ToolStripMenuItem_Click);
            // 
            // вариант3ToolStripMenuItem
            // 
            this.вариант3ToolStripMenuItem.Name = "вариант3ToolStripMenuItem";
            this.вариант3ToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.вариант3ToolStripMenuItem.Text = "Вариант 3";
            this.вариант3ToolStripMenuItem.Click += new System.EventHandler(this.вариант3ToolStripMenuItem_Click);
            // 
            // вариант4ToolStripMenuItem
            // 
            this.вариант4ToolStripMenuItem.Name = "вариант4ToolStripMenuItem";
            this.вариант4ToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.вариант4ToolStripMenuItem.Text = "Вариант 4";
            this.вариант4ToolStripMenuItem.Click += new System.EventHandler(this.вариант4ToolStripMenuItem_Click);
            // 
            // вариант5ToolStripMenuItem
            // 
            this.вариант5ToolStripMenuItem.Name = "вариант5ToolStripMenuItem";
            this.вариант5ToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.вариант5ToolStripMenuItem.Text = "Вариант 5";
            this.вариант5ToolStripMenuItem.Click += new System.EventHandler(this.вариант5ToolStripMenuItem_Click);
            // 
            // задача2ToolStripMenuItem
            // 
            this.задача2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sQLзапросToolStripMenuItem,
            this.recordподходToolStripMenuItem});
            this.задача2ToolStripMenuItem.Name = "задача2ToolStripMenuItem";
            this.задача2ToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.задача2ToolStripMenuItem.Text = "Задача 2";
            // 
            // sQLзапросToolStripMenuItem
            // 
            this.sQLзапросToolStripMenuItem.Name = "sQLзапросToolStripMenuItem";
            this.sQLзапросToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sQLзапросToolStripMenuItem.Text = "SQL-запрос";
            this.sQLзапросToolStripMenuItem.Click += new System.EventHandler(this.sQLзапросToolStripMenuItem_Click);
            // 
            // recordподходToolStripMenuItem
            // 
            this.recordподходToolStripMenuItem.Name = "recordподходToolStripMenuItem";
            this.recordподходToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.recordподходToolStripMenuItem.Text = "Record-подход";
            this.recordподходToolStripMenuItem.Click += new System.EventHandler(this.recordподходToolStripMenuItem_Click);
            // 
            // задача3ToolStripMenuItem
            // 
            this.задача3ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вариант1ToolStripMenuItem1,
            this.вариант2ToolStripMenuItem1});
            this.задача3ToolStripMenuItem.Name = "задача3ToolStripMenuItem";
            this.задача3ToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.задача3ToolStripMenuItem.Text = "Задача 3";
            // 
            // вариант1ToolStripMenuItem1
            // 
            this.вариант1ToolStripMenuItem1.Name = "вариант1ToolStripMenuItem1";
            this.вариант1ToolStripMenuItem1.Size = new System.Drawing.Size(128, 22);
            this.вариант1ToolStripMenuItem1.Text = "Вариант 1";
            this.вариант1ToolStripMenuItem1.Click += new System.EventHandler(this.вариант1ToolStripMenuItem1_Click);
            // 
            // вариант2ToolStripMenuItem1
            // 
            this.вариант2ToolStripMenuItem1.Name = "вариант2ToolStripMenuItem1";
            this.вариант2ToolStripMenuItem1.Size = new System.Drawing.Size(128, 22);
            this.вариант2ToolStripMenuItem1.Text = "Вариант 2";
            this.вариант2ToolStripMenuItem1.Click += new System.EventHandler(this.вариант2ToolStripMenuItem1_Click);
            // 
            // fKCustShipmentBindingSource
            // 
            this.fKCustShipmentBindingSource.DataMember = "FK_Cust_Shipment";
            this.fKCustShipmentBindingSource.DataSource = this.customersBindingSource;
            // 
            // fKDetShipmentBindingSource
            // 
            this.fKDetShipmentBindingSource.DataMember = "FK_Det_Shipment";
            this.fKDetShipmentBindingSource.DataSource = this.detailsBindingSource;
            // 
            // myDataSetBindingSource
            // 
            this.myDataSetBindingSource.DataSource = this.myDataSet;
            this.myDataSetBindingSource.Position = 0;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // detailsTableAdapter
            // 
            this.detailsTableAdapter.ClearBeforeFill = true;
            // 
            // acc_ShipmentTableAdapter
            // 
            this.acc_ShipmentTableAdapter.ClearBeforeFill = true;
            // 
            // selfDetailsTableAdapter
            // 
            this.selfDetailsTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(999, 541);
            this.Controls.Add(this.dgvUnion);
            this.Controls.Add(this.lblAcc_Shipment);
            this.Controls.Add(this.lblDetails);
            this.Controls.Add(this.lblCustomers);
            this.Controls.Add(this.lblProc);
            this.Controls.Add(this.btnProc);
            this.Controls.Add(this.lblDate_to);
            this.Controls.Add(this.lblDate_from);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.btnPrev);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dgvAcc_Shipment);
            this.Controls.Add(this.dgvDetails);
            this.Controls.Add(this.bindingNavigator1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.dgvCustomers);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(20, 20);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(1015, 580);
            this.MinimumSize = new System.Drawing.Size(1015, 580);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Курсовой проект по БД";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.detailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAcc_Shipment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.selfDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accShipmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUnion)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fKCustShipmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKDetShipmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvCustomers;
        private myDataSet myDataSet;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private myDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.DataGridView dgvDetails;
        private System.Windows.Forms.DataGridView dgvAcc_Shipment;
        private System.Windows.Forms.BindingSource detailsBindingSource;
        private myDataSetTableAdapters.DetailsTableAdapter detailsTableAdapter;
        private System.Windows.Forms.BindingSource accShipmentBindingSource;
        private myDataSetTableAdapters.Acc_ShipmentTableAdapter acc_ShipmentTableAdapter;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.BindingSource fKCustShipmentBindingSource;
        private System.Windows.Forms.BindingSource fKDetShipmentBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameCUSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addCUSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeDETDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDETDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitDETDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDETDataGridViewTextBoxColumn;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label lblDate_from;
        private System.Windows.Forms.Label lblDate_to;
        private System.Windows.Forms.Button btnProc;
        private System.Windows.Forms.Label lblProc;
        private System.Windows.Forms.Label lblCustomers;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.Label lblAcc_Shipment;
        private System.Windows.Forms.DataGridView dgvUnion;
        private System.Windows.Forms.BindingSource myDataSetBindingSource;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem формыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem основнаяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задача1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вариант1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вариант2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вариант3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вариант4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вариант5ToolStripMenuItem;
        private ToolStripMenuItem альтернативнаяToolStripMenuItem;
        private ToolStripMenuItem представлениеToolStripMenuItem;
        private ToolStripMenuItem задача2ToolStripMenuItem;
        private ToolStripMenuItem sQLзапросToolStripMenuItem;
        private ToolStripMenuItem recordподходToolStripMenuItem;
        private ToolStripMenuItem задача3ToolStripMenuItem;
        private ToolStripMenuItem вариант1ToolStripMenuItem1;
        private ToolStripMenuItem вариант2ToolStripMenuItem1;
        private BindingSource selfDetailsBindingSource;
        private myDataSetTableAdapters.SelfDetailsTableAdapter selfDetailsTableAdapter;
        private DataGridViewTextBoxColumn codeDOCDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn code_STRG;
        private DataGridViewTextBoxColumn dateSHIPMENTDataGridViewTextBoxColumn;
        private DataGridViewComboBoxColumn code_CUS;
        private DataGridViewComboBoxColumn code_RPROD;
        private DataGridViewTextBoxColumn unitPRODDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn countPRODDataGridViewTextBoxColumn;
    }
}

