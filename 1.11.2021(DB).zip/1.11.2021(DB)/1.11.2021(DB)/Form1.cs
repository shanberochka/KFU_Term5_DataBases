﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1._11._2021_DB_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.SelfDetails". При необходимости она может быть перемещена или удалена.
            this.selfDetailsTableAdapter.Fill(this.myDataSet.SelfDetails);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.Acc_Shipment". При необходимости она может быть перемещена или удалена.
            this.acc_ShipmentTableAdapter.Fill(this.myDataSet.Acc_Shipment);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.Details". При необходимости она может быть перемещена или удалена.
            this.detailsTableAdapter.Fill(this.myDataSet.Details);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myDataSet.Customers". При необходимости она может быть перемещена или удалена.
            this.customersTableAdapter.Fill(this.myDataSet.Customers);
        }

        private void dgvCustomers_Click(object sender, EventArgs e)
        {
            bindingNavigator1.BindingSource = customersBindingSource;
            lbl.Text = "Customers";
            dgvAcc_Shipment.DataSource = fKCustShipmentBindingSource;
        }

        private void dgvDetails_Click(object sender, EventArgs e)
        {
            bindingNavigator1.BindingSource = detailsBindingSource;
            lbl.Text = "Details";
            dgvAcc_Shipment.DataSource = fKDetShipmentBindingSource;
        }

        private void dgvAcc_Shipment_Click(object sender, EventArgs e)
        {
            dgvAcc_Shipment.DataSource = accShipmentBindingSource;
            lbl.Text = "Orders";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                acc_ShipmentTableAdapter.Update(myDataSet.Acc_Shipment);
                detailsTableAdapter.Update(myDataSet.Details);
                customersTableAdapter.Update(myDataSet.Customers);
                MessageBox.Show("Changes are saved!");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            int col = dgvAcc_Shipment.CurrentCell.ColumnIndex;
            int row = dgvAcc_Shipment.CurrentCell.RowIndex;

            dgvAcc_Shipment.CurrentCell = dgvAcc_Shipment[col, (row + 1) % dgvAcc_Shipment.RowCount];
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            int col = dgvAcc_Shipment.CurrentCell.ColumnIndex;
            int row = dgvAcc_Shipment.CurrentCell.RowIndex;

            if (row > 0)
            {
                dgvAcc_Shipment.CurrentCell = dgvAcc_Shipment[col, row - 1];
            }
            else
            {
                dgvAcc_Shipment.CurrentCell = dgvAcc_Shipment[col, dgvAcc_Shipment.RowCount - 1];
            }
        }

        private void btnProc_Click(object sender, EventArgs e)
        {
            string conStr = Properties.Settings.Default.myBase913ConnectionString;
            string cus_name = dgvCustomers.CurrentRow.Cells["nameCUSDataGridViewTextBoxColumn"].Value.ToString();

            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand()
            {
                Connection = con,
                CommandType = CommandType.StoredProcedure,
                CommandText = "Get_Count_Det"
            };
          
            cmd.Parameters.AddWithValue("@cust_name", cus_name);
            cmd.Parameters.AddWithValue("@date1", dateTimePicker1.Value);
            cmd.Parameters.AddWithValue("@date2", dateTimePicker2.Value);

            SqlParameter par = new SqlParameter()
            {
                ParameterName = "@count",
                Direction = ParameterDirection.Output,
                SqlDbType = SqlDbType.Int
            };

            cmd.Parameters.Add(par);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                string res = cmd.Parameters["@count"].Value.ToString();
                lblProc.Text = $"Result: {res}";

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void вариант1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Zadacha1v1 z11 = new Zadacha1v1();
            z11.ShowDialog();
        }

        private void вариант2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Zadacha1v2 z12 = new Zadacha1v2();
            z12.ShowDialog();
        }

        private void вариант3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Zadacha1v3 z1v3 = new Zadacha1v3();
            z1v3.ShowDialog();
        }

        private void вариант4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Zadacha1v4 z1v4 = new Zadacha1v4();
            z1v4.ShowDialog();
        }

        private void вариант5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Zadacha1v5 z1v5 = new Zadacha1v5();
            z1v5.ShowDialog();
        }

        private void dgvAcc_Shipment_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            
        }

        private void альтернативнаяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AlterForm af = new AlterForm();
            af.ShowDialog();
        }

        private void представлениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            View_Form vf = new View_Form();
            vf.ShowDialog();
        }

        private void sQLзапросToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Zadacha2v1 z2v1 = new Zadacha2v1();
            z2v1.ShowDialog();
        }

        private void recordподходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Zadacha2v2 z2v2 = new Zadacha2v2();
            z2v2.ShowDialog();
        }

        private void вариант1ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Zadacha3v1 z3c1 = new Zadacha3v1();
            z3c1.ShowDialog();
        }

        private void вариант2ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Zadacha3v2 z3c2 = new Zadacha3v2();
            z3c2.ShowDialog();
        }


    }
}
