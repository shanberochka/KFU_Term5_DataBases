﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1._11._2021_DB_
{
    public partial class Zadacha1v5 : Form
    {
        public Zadacha1v5()
        {
            InitializeComponent();
        }
        private void btnFill_Click(object sender, EventArgs e)
        {
            FillbyDataReader();
        }
        private void FillbyDataReader()
        {
            string conStr = Properties.Settings.Default.myBase913ConnectionString;
            //string cus_name = dgvCustomers.CurrentRow.Cells["nameCUSDataGridViewTextBoxColumn"].Value.ToString();

            SqlConnection con = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT        Details.name_DET, Acc_Shipment.date_SHIPMENT, Details.price_DET, Acc_Shipment.count_PROD"
                               + " FROM Acc_Shipment INNER JOIN"
                               + " Details ON Acc_Shipment.code_RPROD = Details.code_DET"
                               + " WHERE Acc_Shipment.count_PROD >= @count";
                               //+ " WHERE Acc_Shipment.count_PROD >= " + txtCount.Text;

            cmd.Parameters.AddWithValue("@count", int.Parse(txtCount.Text));

            try
            {
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(rdr);
                
                BindingSource bs = new BindingSource();
                bs.DataSource = dt;
                zadacha1BindingNavigator.BindingSource = bs;
                dgvZadacha1.DataSource = bs;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Zadacha1v5_Load(object sender, EventArgs e)
        {
            FillbyDataReader();
        }

        private void txtCount_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                FillbyDataReader();
            }
        }

    }
}
